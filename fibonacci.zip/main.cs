using System;

class Program {
  static void Main(string[] args) {
    int n = 18; // Número que eu escolhi 
    int a = 0;       // Variáveis da sequência 
    int b = 1;
    int c = 0;
    
    // percorre a sequência de Fibonacci até encontrar um número igual ou maior que n
    while (c < n) {
      c = a + b;
      a = b;
      b = c;
    }

    
    if (c == n) {
      Console.WriteLine($"{n} nao faz parte da sequência ");
    } else {
      Console.WriteLine($"{n} não faz parte da sequência ");
    }
  }
}



